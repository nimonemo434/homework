* Ensure all files are UTF8
