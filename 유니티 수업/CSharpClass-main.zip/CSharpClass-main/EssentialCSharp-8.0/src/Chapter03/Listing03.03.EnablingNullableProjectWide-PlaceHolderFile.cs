using System;
using System.Collections.Generic;
using System.Text;

namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_03
{
    class Listing03
    {
    }
}

//��ŵ