﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter10.Listing10_16
{
    // Define the namespace AddisonWesley.Michaelis.EssentialCSharp
    namespace AddisonWesley.Michaelis.EssentialCSharp
    {
        class Program
        {
            // ...
        }
    }
    // End of AddisonWesley namespace declaration 
}