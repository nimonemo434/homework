namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter12.Listing12_08
{
    interface IPair<T>
    {
        T First { get; set; }
        T Second { get; set; }
    }
}
