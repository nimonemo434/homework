﻿namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_01
{
    public class Program
    {
        public static void Main()
        {
            int kk = 42;
            //리터럴 값(거의 안쓰는 말)
            System.Console.WriteLine(kk);
            System.Console.WriteLine(1.618034);

            char testChar = 'd';
            int testInt = 3;
            long testLong = 3;
            float testFloat = 3;
            string testString = "hello World";
            double testDouble = 3;
            float testFloat2 = 3.3f;
            double testDouble2 = 3.3d;

        }
    }
}


/*
 
 PPT 참고
 1주차 P.14
 
 
 */