namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter06.Listing06_25
{
  .property instance string FirstName()
    {
    .get instance string Program::get_FirstName()
    .set instance void Program::set_FirstName(string)
  } // End of property Program::FirstName

}

//��ŵ