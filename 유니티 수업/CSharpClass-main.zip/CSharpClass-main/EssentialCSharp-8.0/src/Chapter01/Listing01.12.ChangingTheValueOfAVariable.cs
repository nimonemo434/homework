namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_12
{
    public class MiracleMax
    {
        public static void Main()
        {
            string valerie;
            string miracleMax = "Have fun storming the castle!"; //���� �Ҵ� (�ʱ�ȭ) - �Ҵ� ������ =

            valerie = "Think it will work?";    //���� �Ҵ�

            System.Console.WriteLine(miracleMax);
            System.Console.WriteLine(valerie);

            miracleMax = "It would take a miracle.";    //���� �Ҵ�
            System.Console.WriteLine(miracleMax);
        }
    }
}
