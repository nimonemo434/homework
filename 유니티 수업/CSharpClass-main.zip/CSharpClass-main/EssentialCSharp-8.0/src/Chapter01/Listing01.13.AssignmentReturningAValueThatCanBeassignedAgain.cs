namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_13
{
    public class MiracleMax
    {
        public static void Main()
        {
            // ...
            string requirements, miracleMax;
            requirements = miracleMax = "It would take a miracle."; //���� ���� ����

            System.Console.WriteLine(miracleMax);

        }
    }
}


