namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter03.Listing03_19
{
    public class Program
    {
        public static void Main()
        {
            int[][] cells = {
                new int[] {1, 0, 2, 0},
                new int[] {1, 2, 0},
                new int[] {1, 2},
                new int[] {1}
            };
        }
    }
}
