namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_11
{
    public class Program
    {
        public static void Main()
        {
            int x = 123;
            x += 2;
        }
    }
}
