namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_17
{
    public class Program
    {
        public static void Main()
        {
            int count = 123;
            int result;
            result = ++count;
            System.Console.WriteLine(
                $"result = {result} and count = {count}");
        }
    }
}
