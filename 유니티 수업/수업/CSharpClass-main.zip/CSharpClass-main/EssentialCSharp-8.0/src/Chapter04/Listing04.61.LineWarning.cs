namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_61
{
    public class Program
    {
        public static void Main()
        {
#line 113 "TicTacToe.cs"
#warning "Same move allowed multiple times."
#line default
        }
    }
}

//��ŵ