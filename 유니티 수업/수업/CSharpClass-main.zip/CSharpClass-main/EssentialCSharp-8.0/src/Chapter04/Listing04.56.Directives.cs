namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter04.Listing04_56
{
    public class Program
    {
        public static void Main()
        {
#if LINUX
            // ...
#elif WINDOWS
            // ...
#endif
        }
    }
}

//��ó����