namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_08
{
    public class Program
    {
        public static void Main()
        {
            //Displays "0x2A" _ 16����
            System.Console.WriteLine($"0x{42:X}");
        }
    }
}
