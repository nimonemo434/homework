namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter02.Listing02_06
{
    public class Program
    {
        public static void Main()
        {
            //16���� ����
            System.Console.WriteLine(0x002A);
        }
    }
}
