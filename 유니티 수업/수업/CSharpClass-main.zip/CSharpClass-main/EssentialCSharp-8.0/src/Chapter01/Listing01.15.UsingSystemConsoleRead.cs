namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_15
{
    public class Program
    {
        public static void Main()
        {
            int readValue;
            char character;
            readValue = System.Console.Read();
            character = (char) readValue;
            System.Console.Write(character);
        }
    }
}

//��ŵ