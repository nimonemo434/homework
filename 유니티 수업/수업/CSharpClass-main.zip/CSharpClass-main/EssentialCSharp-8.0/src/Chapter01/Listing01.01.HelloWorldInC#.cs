namespace AddisonWesley.Michaelis.EssentialCSharp.Chapter01.Listing01_01
{
    public class HelloWorld
    {
        public static void Main()
        {
            System.Console.WriteLine("Hello. My name is Inigo Montoya.");
        }
    }
}
